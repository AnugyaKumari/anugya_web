<?php 
the_archive_description( '<div class="taxonomy-description">', '</div>' );

?>